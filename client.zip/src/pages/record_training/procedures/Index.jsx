import React from "react";

const Procedures = () => {
  return <div>Procedures</div>;
};

export default Procedures;
