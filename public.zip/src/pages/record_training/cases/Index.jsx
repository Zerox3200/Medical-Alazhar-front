import React from "react";
import { Outlet } from "react-router";

const Cases = () => {
  return (
    <div>
      <Outlet />
    </div>
  );
};

export default Cases;
